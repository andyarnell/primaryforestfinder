"""
PFF Tool 5 – Refine Output
============================
Removes isolated small forest patches using neighbourhood density
filtering.  A circular moving window computes the proportion of forest
pixels in each pixel's neighbourhood.  Pixels below the density threshold
are removed.  The result is masked to the input forest candidate layer.

Three computation backends (DO NOT remove the fallbacks — they exist
for portability, not dead code):

  1. **FFT circular** (``_circular_focal_mean_fft``)
     Uses ``scipy.signal.fftconvolve`` — O(n log n) regardless of kernel
     size.  Fast (~5 min for Ecuador 30m) with exact circular kernel.
     Requires scipy, which ships with QGIS on Windows/OSGeo4W and macOS
     .dmg since at least QGIS 3.16.

  2. **Integral-image circular** (``_circular_focal_mean_integral``)
     Pure numpy — no optional dependencies.  Guaranteed to work on ANY
     QGIS install (numpy is a hard QGIS dependency).  Slower than FFT
     (~45 min for Ecuador 30m) because it loops over the kernel diameter,
     but memory-efficient via slice-based views.  This is the fallback
     when scipy is not installed (e.g. some Linux package-manager QGIS
     builds).

  3. **Square box filter** (``_square_focal_mean_fast``)
     Single integral-image slice — O(1), near-instant.  ~27% shape
     difference at edges vs circle.  Used when the user ticks
     "Fast approximation" or when radius exceeds 5000 m.

The dispatcher ``_circular_focal_mean_fast`` picks (1) or (2) at
runtime based on scipy availability.  ``refine_output`` picks between
circular and square based on the ``fast_approximation`` flag and radius.

Processing is tiled (512-row strips with radius overlap) to keep peak
memory under ~1 GB per tile even for national-scale 30m rasters.

Compatible with QGIS >= 3.28.
"""

import os
import numpy as np
from osgeo import gdal

from qgis.core import (
    QgsProcessingAlgorithm,
    QgsProcessingParameterRasterLayer,
    QgsProcessingParameterNumber,
    QgsProcessingParameterBoolean,
    QgsProcessingParameterRasterDestination,
)

from ..utils import raster_resolution


class ConnectivityFilterAlgorithm(QgsProcessingAlgorithm):
    INPUT = "INPUT"
    # Step (a) -- neighbourhood density filter
    SMOOTH_RADIUS = "SMOOTH_RADIUS"
    DENSITY_THRESHOLD = "DENSITY_THRESHOLD"
    FAST_APPROXIMATION = "FAST_APPROXIMATION"
    # Step (b) -- minimum patch size (raster sieve)
    MIN_PATCH_AREA_HA = "MIN_PATCH_AREA_HA"
    OUTPUT = "OUTPUT"

    def name(self):
        return "refine_output"

    def displayName(self):
        return "5 — Refine Output"

    def group(self):
        return "Primary Forest Finder"

    def groupId(self):
        return "pff"

    def shortHelpString(self):
        return (
            "Refines the primary-forest candidate raster via two "
            "optional steps. Each can run independently or together "
            "(neighbourhood first, then sieve).\n\n"
            "Step (a) -- Neighbourhood density filter:\n"
            "  Circular kernel computes the proportion of forest pixels "
            "around each pixel. Pixels below the density threshold are "
            "removed. For radii above 5000 m a faster square kernel is "
            "used (approximate). Set radius = 0 to skip this step.\n"
            "  Defaults: radius = 2000 m, density threshold = 0.5.\n\n"
            "Step (b) -- Minimum patch size filter (raster sieve):\n"
            "  Removes connected raster groups smaller than the chosen "
            "patch area (hectares) via gdal:sieve. Threshold is "
            "computed from the raster pixel area at run time. Set to 0 "
            "to skip this step.\n\n"
            "Both steps off -> the input is copied to the output as-is.\n\n"
            "Output: primary_forest.tif"
        )

    def createInstance(self):
        return ConnectivityFilterAlgorithm()

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterRasterLayer(
            self.INPUT, "Primary forest candidate raster"))
        # Step (a)
        self.addParameter(QgsProcessingParameterNumber(
            self.SMOOTH_RADIUS,
            "Step (a) Neighbourhood radius (m); 0 = skip step (a)",
            type=QgsProcessingParameterNumber.Double,
            defaultValue=2000, minValue=0, maxValue=10000))
        self.addParameter(QgsProcessingParameterNumber(
            self.DENSITY_THRESHOLD,
            "Step (a) Minimum density to keep (0-1)",
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.5, minValue=0, maxValue=1))
        self.addParameter(QgsProcessingParameterBoolean(
            self.FAST_APPROXIMATION,
            "Step (a) Fast approximation (square kernel — ~100x faster, ~27% shape difference at edges)",
            defaultValue=False))
        # Step (b)
        self.addParameter(QgsProcessingParameterNumber(
            self.MIN_PATCH_AREA_HA,
            "Step (b) Minimum patch area, hectares (0 = skip step (b))",
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.0, minValue=0.0))
        self.addParameter(QgsProcessingParameterRasterDestination(
            self.OUTPUT, "Primary forest (refined) output"))

    def processAlgorithm(self, parameters, context, feedback):
        import math
        import os
        import tempfile

        import numpy as np
        from osgeo import gdal as _gdal

        from qgis.core import QgsProcessingException
        from ..utils import ensure_dir, run_processing

        input_layer = self.parameterAsRasterLayer(
            parameters, self.INPUT, context)
        radius_m = self.parameterAsDouble(
            parameters, self.SMOOTH_RADIUS, context)
        threshold = self.parameterAsDouble(
            parameters, self.DENSITY_THRESHOLD, context)
        fast = self.parameterAsBool(
            parameters, self.FAST_APPROXIMATION, context)
        min_patch_area_ha = self.parameterAsDouble(
            parameters, self.MIN_PATCH_AREA_HA, context)
        out_path = self.parameterAsOutputLayer(
            parameters, self.OUTPUT, context)

        step_a_on = radius_m > 0
        step_b_on = min_patch_area_ha > 0

        if not step_a_on and not step_b_on:
            feedback.pushInfo(
                "Both refine steps off (radius=0, min_patch_area_ha=0) -- "
                "copying input to output unchanged.")
            run_processing("gdal:translate", {
                "INPUT": input_layer.source(),
                "OUTPUT": out_path,
            }, context=context, feedback=feedback)
            return {self.OUTPUT: out_path}

        # Decide intermediate path: if both steps run, step (a) writes to
        # a scratch tif and step (b) reads it; if only one runs, it writes
        # straight to out_path.
        scratch_dir = ensure_dir(tempfile.mkdtemp(prefix="pff_refine_"))
        if step_a_on and step_b_on:
            step_a_out = os.path.join(scratch_dir, "step_a_neighbourhood.tif")
            step_b_in = step_a_out
            step_b_out = out_path
        elif step_a_on:
            step_a_out = out_path
            step_b_in = None
            step_b_out = None
        else:
            step_a_out = None
            step_b_in = input_layer.source()
            step_b_out = out_path

        if step_a_on:
            feedback.pushInfo(
                f"Step (a) Neighbourhood density (radius={radius_m:g} m, "
                f"density>={threshold:g}, fast={fast})...")
            refine_output(
                input_layer.source(), step_a_out,
                radius_m=radius_m, threshold=threshold,
                fast_approximation=fast,
                feedback=feedback)

        if feedback.isCanceled():
            raise QgsProcessingException(
                "Cancelled by user (between Refine Output steps).")

        if step_b_on:
            # Compute pixel-count threshold from hectares + pixel area.
            from ..utils import raster_resolution
            res = raster_resolution(step_b_in)
            pixel_area_m2 = res * res
            min_area_m2 = min_patch_area_ha * 10000.0
            threshold_px = max(1, math.ceil(min_area_m2 / pixel_area_m2))
            feedback.pushInfo(
                f"Step (b) Minimum patch size: removing connected groups < "
                f"{threshold_px} px (~{min_patch_area_ha:g} ha) via gdal:sieve...")

            # Sieve to a scratch tif first; then mask back to input forest
            # (gdal:sieve fills small "0-holes" inside larger "1" regions
            # by replacing them with the surrounding value, which would
            # introduce pixels outside the input forest extent. The mask-
            # back step matches the principle Step (a)'s neighbourhood
            # filter already applies internally).
            sieve_tmp = os.path.join(scratch_dir, "step_b_sieved.tif")
            run_processing("gdal:sieve", {
                "INPUT": step_b_in,
                "THRESHOLD": threshold_px,
                "EIGHT_CONNECTEDNESS": False,
                "OUTPUT": sieve_tmp,
            }, context=context, feedback=feedback)

            feedback.pushInfo(
                "Step (b) masking sieve result back to input forest "
                "(prevents hole-fill from creating pixels outside the "
                "input extent)...")
            _ds_sv = _gdal.Open(sieve_tmp, _gdal.GA_ReadOnly)
            sv_arr = _ds_sv.GetRasterBand(1).ReadAsArray()
            sv_gt = _ds_sv.GetGeoTransform()
            sv_proj = _ds_sv.GetProjection()
            sv_xsz = _ds_sv.RasterXSize
            sv_ysz = _ds_sv.RasterYSize
            _ds_sv = None
            _ds_in = _gdal.Open(step_b_in, _gdal.GA_ReadOnly)
            in_arr = _ds_in.GetRasterBand(1).ReadAsArray()
            _ds_in = None
            masked = ((sv_arr == 1) & (in_arr == 1)).astype(np.uint8)
            drv = _gdal.GetDriverByName("GTiff")
            if os.path.exists(step_b_out):
                try:
                    os.remove(step_b_out)
                except OSError:
                    pass
            _ds_out = drv.Create(step_b_out, sv_xsz, sv_ysz, 1,
                                 _gdal.GDT_Byte,
                                 ["COMPRESS=LZW", "TILED=YES"])
            _ds_out.SetGeoTransform(sv_gt)
            _ds_out.SetProjection(sv_proj)
            _ob = _ds_out.GetRasterBand(1)
            _ob.WriteArray(masked)
            _ob.SetNoDataValue(0)
            _ob.FlushCache()
            _ds_out = None

        feedback.pushInfo("Refine output complete.")
        return {self.OUTPUT: out_path}



def _circular_focal_mean_fft(arr, radius_px, feedback=None):
    """Compute circular neighbourhood mean via FFT convolution.

    Uses scipy.signal.fftconvolve — O(n log n) regardless of kernel size.
    Much faster than the integral-image loop for large radii while
    maintaining exact circular kernel shape.

    Requires scipy (ships with QGIS on Windows/OSGeo4W).
    """
    from scipy.signal import fftconvolve

    if feedback:
        feedback.pushInfo("Using FFT circular convolution (fast + exact)...")

    # Build normalised circular kernel
    y, x = np.ogrid[-radius_px:radius_px + 1, -radius_px:radius_px + 1]
    kernel = ((x * x + y * y) <= radius_px * radius_px).astype(np.float64)
    kernel /= kernel.sum()

    # FFT convolution (mode='same' returns same shape as input)
    density = fftconvolve(arr.astype(np.float64), kernel, mode='same')

    if feedback:
        feedback.setProgress(80)

    return density


def _circular_focal_mean_integral(arr, radius_px, feedback=None):
    """Compute circular neighbourhood mean using slice-based integral image.

    Fallback for systems without scipy.  Slower (loops over kernel diameter)
    but still memory-efficient via slice views.
    """
    rows, cols = arr.shape
    pad = radius_px + 1
    padded = np.pad(arr.astype(np.float64), pad, mode='constant',
                    constant_values=0)
    integral = padded.cumsum(axis=0).cumsum(axis=1)

    acc = np.zeros((rows, cols), dtype=np.float64)
    n_pixels = 0

    for dy in range(-radius_px, radius_px + 1):
        if feedback and feedback.isCanceled():
            return None
        dx_max = int(np.floor(np.sqrt(max(0, radius_px**2 - dy**2))))
        if dx_max < 0:
            continue

        n_pixels += 2 * dx_max + 1
        r1 = pad + dy - 1
        r2 = pad + dy
        c1 = pad - dx_max
        c2 = pad + dx_max + 1

        acc += (integral[r2:r2 + rows, c2:c2 + cols]
                - integral[r2:r2 + rows, c1:c1 + cols]
                - integral[r1:r1 + rows, c2:c2 + cols]
                + integral[r1:r1 + rows, c1:c1 + cols])

        if feedback:
            progress = int((dy + radius_px + 1) / (2 * radius_px + 1) * 80)
            feedback.setProgress(progress)

    if n_pixels == 0:
        n_pixels = 1
    return acc / n_pixels


# Check scipy availability once at import time
try:
    from scipy.signal import fftconvolve as _fft_check  # noqa: F401
    _HAS_SCIPY = True
except ImportError:
    _HAS_SCIPY = False


def _circular_focal_mean_fast(arr, radius_px, feedback=None):
    """Dispatch to FFT (preferred) or integral-image fallback."""
    if _HAS_SCIPY:
        return _circular_focal_mean_fft(arr, radius_px, feedback)
    else:
        if feedback:
            feedback.pushInfo(
                "scipy not available — using slower integral-image method.")
        return _circular_focal_mean_integral(arr, radius_px, feedback)


def _square_focal_mean_fast(arr, radius_px, feedback=None):
    """Compute square neighbourhood mean — uses scipy if available.

    With scipy: ``ndimage.uniform_filter`` — separable C implementation,
    O(1) per pixel, no allocations, extremely fast.
    Without scipy: numpy integral-image fallback.
    """
    side = 2 * radius_px + 1

    if feedback:
        feedback.pushInfo(
            f"Using square kernel (area-corrected, side={side}px)...")

    if _HAS_SCIPY:
        from scipy.ndimage import uniform_filter
        # uniform_filter uses 'reflect' mode by default; 'constant' matches
        # our zero-padding behaviour for edge pixels
        density = uniform_filter(
            arr.astype(np.float64), size=side, mode='constant', cval=0.0)
        if feedback:
            feedback.setProgress(80)
        return density

    # Fallback: numpy integral image
    rows, cols = arr.shape
    pad = radius_px + 1
    padded = np.pad(arr.astype(np.float64), pad, mode='constant',
                    constant_values=0)
    integral = padded.cumsum(axis=0).cumsum(axis=1)

    box_sum = (integral[side:side + rows, side:side + cols]
               - integral[0:rows, side:side + cols]
               - integral[side:side + rows, 0:cols]
               + integral[0:rows, 0:cols])

    if feedback:
        feedback.setProgress(80)

    return box_sum / (side * side)


# Threshold in metres: above this, use square kernel (fast approximate)
_CIRCLE_TO_SQUARE_THRESHOLD_M = 5000

# Target tile height in pixels — kept small to avoid OOM on wide rasters.
# Each tile uses ~3x (tile_h + 2*radius) * width * 8 bytes for float64.
_TARGET_TILE_ROWS = 512


def refine_output(input_path, output_path, radius_m=2000, threshold=0.5,
                  fast_approximation=False, feedback=None):
    """Neighbourhood density filter for removing isolated patches.

    Processes the raster in overlapping row-strips (tiles) to keep memory
    bounded.  Uses circular kernel up to 5000m, square above — unless
    fast_approximation=True which forces square at any radius (~100x faster).
    """
    ds = gdal.Open(input_path, gdal.GA_ReadOnly)
    band = ds.GetRasterBand(1)
    gt = ds.GetGeoTransform()
    proj = ds.GetProjection()
    x_size = ds.RasterXSize
    y_size = ds.RasterYSize

    res = abs(gt[1])
    radius_px = max(1, int(round(radius_m / res)))

    # Backstop (defence-in-depth). If the raster reaches here still in a
    # geographic CRS (degrees) -- e.g. the upstream target-CRS guard was
    # bypassed by an empty/invalid CRS -- then radius_m / res explodes
    # (2000 m / ~0.0008 deg ≈ 2.5M px) and building the (2r+1)^2 kernel
    # below would try to allocate hundreds of TiB. Fail with a clear,
    # actionable message instead of a raw numpy MemoryError.
    _is_geographic = False
    if proj:
        try:
            from osgeo import osr
            _srs = osr.SpatialReference()
            _srs.ImportFromWkt(proj)
            _is_geographic = bool(_srs.IsGeographic())
        except Exception:
            _is_geographic = False
    if _is_geographic or radius_px > 1_000_000:
        from qgis.core import QgsProcessingException
        raise QgsProcessingException(
            "Refine Output cannot run: the input raster appears to be in a "
            "geographic CRS (degrees), so a {rm:g} m neighbourhood resolves "
            "to {rp} pixels (pixel size {res:g}) and the kernel would need "
            "hundreds of TiB of memory. Set a projected target CRS in metres "
            "(a UTM zone or your national grid) and re-run.".format(
                rm=radius_m, rp=radius_px, res=res))

    use_square = fast_approximation or (radius_m > _CIRCLE_TO_SQUARE_THRESHOLD_M)

    # Area-correct the square radius so total kernel pixels ≈ circle's.
    # Without this, square has 4/π ≈ 27% more pixels → biases results.
    if use_square:
        radius_px = max(1, int(round(radius_px * 0.886)))

    if feedback:
        mode = "square (area-corrected)" if use_square else "circle (exact)"
        feedback.pushInfo(
            f"Refine output: radius={radius_m}m ({radius_px}px), "
            f"threshold={threshold}, kernel={mode}, "
            f"raster={x_size}x{y_size}")
        feedback.pushInfo(
            "Refine output: density result is masked back to input forest "
            "(matches GEE pff_4.js — pixels outside input forest are excluded)")

    # Determine tiling
    tile_rows = max(_TARGET_TILE_ROWS, 2 * radius_px + 1)
    n_tiles = max(1, (y_size + tile_rows - 1) // tile_rows)
    if n_tiles > 1 and feedback:
        feedback.pushInfo(
            f"Processing in {n_tiles} tiles (tile height={tile_rows}px, "
            f"overlap={radius_px}px)")

    # Create output
    driver = gdal.GetDriverByName("GTiff")
    out_ds = driver.Create(output_path, x_size, y_size, 1, gdal.GDT_Byte,
                           options=["COMPRESS=LZW", "TILED=YES"])
    out_ds.SetGeoTransform(gt)
    out_ds.SetProjection(proj)
    out_band = out_ds.GetRasterBand(1)
    out_band.SetNoDataValue(0)

    original_count = 0
    refined_count = 0

    for tile_idx in range(n_tiles):
        if feedback and feedback.isCanceled():
            out_ds = None
            return output_path

        # Compute row range for this tile (with overlap)
        row_start = tile_idx * tile_rows
        row_end = min(row_start + tile_rows, y_size)

        # Expand by radius_px for overlap (clamped to raster bounds)
        read_start = max(0, row_start - radius_px)
        read_end = min(y_size, row_end + radius_px)

        # Read tile with overlap
        tile_arr = band.ReadAsArray(0, read_start, x_size,
                                    read_end - read_start).astype(np.float32)

        # Compute density for this tile
        tile_radius = radius_px
        if use_square:
            density = _square_focal_mean_fast(tile_arr, tile_radius)
        else:
            density = _circular_focal_mean_fast(tile_arr, tile_radius)

        if density is None:
            out_ds = None
            return output_path

        # Extract the non-overlapping core from the density result
        core_top = row_start - read_start
        core_bot = core_top + (row_end - row_start)
        core_density = density[core_top:core_bot, :]
        core_arr = tile_arr[core_top:core_bot, :]

        # Threshold and mask
        refined_tile = ((core_density >= threshold) &
                        (core_arr == 1)).astype(np.uint8)

        original_count += int((core_arr == 1).sum())
        refined_count += int(refined_tile.sum())

        # Write to output
        out_band.WriteArray(refined_tile, 0, row_start)

        if feedback:
            progress = int((tile_idx + 1) / n_tiles * 90)
            feedback.setProgress(progress)

    ds = None
    out_band.FlushCache()
    out_ds = None

    # Report
    removed = original_count - refined_count
    if feedback:
        feedback.pushInfo(
            f"Kept {refined_count:,} of {original_count:,} forest pixels "
            f"({removed:,} removed, "
            f"{100 * removed / max(original_count, 1):.1f}%)")
        feedback.setProgress(95)

    return output_path
